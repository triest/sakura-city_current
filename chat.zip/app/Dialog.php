<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dialog extends Model
{
    //
    protected $table = 'dialogs';
}
