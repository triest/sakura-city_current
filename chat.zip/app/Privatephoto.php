<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Privatephoto extends Model
{
    //
    protected $table = "private_photos";
}
