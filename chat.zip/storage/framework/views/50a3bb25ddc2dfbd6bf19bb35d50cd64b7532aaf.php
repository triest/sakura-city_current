<?php $__env->startSection('content'); ?>
    <div class="card-body" id="applicationClass">
        <application :user="<?php echo e(auth()->user()); ?>"></application>
    </div>
    <b><a class="button blue" href="<?php echo e(route('main')); ?>" role="link" onclick=" relocate_home()">К списку анкет</a></b>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', ['title' => 'Заявки на открытие анкеты'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>