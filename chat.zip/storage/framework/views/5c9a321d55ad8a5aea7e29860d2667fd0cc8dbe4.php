<?php $__env->startSection('content'); ?>
    <div class="card-body" id="app3">
        <editimages :user="<?php echo e(auth()->user()); ?>"></editimages>
    </div>
    <br>
    <a class="btn btn-primary" href="<?php echo e(route('main')); ?>" role="link" onclick=" relocate_home()">Назад</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', ['title' => 'Редактировать галлерею'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>