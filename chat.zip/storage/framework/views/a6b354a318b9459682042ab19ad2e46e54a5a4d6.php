<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $girls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $girl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- md -комп-->
        <div class="col-lg-4 col-md-3 col-sm-5 col-xs-9 ">
            <a href="<?php echo e(route('showGirl',['id'=>$girl->id])); ?>">
                <img height="200" width="200"
                     src="<?php echo asset("/images/small/$girl->main_image")?>"></a>
            </a>
            <h4 class="card-title">
                <b> <a href="<?php echo e(route('showGirl',['id'=>$girl->id])); ?>"><?php echo e($girl->name); ?></a></b>
            </h4>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo $girls->render(); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
    <script>
        baguetteBox.run('.tz-gallery');
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', ['title' => 'Список анкет'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>