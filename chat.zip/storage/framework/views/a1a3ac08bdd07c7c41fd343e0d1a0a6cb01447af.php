<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title); ?></title>
    <script src="https://getbootstrap.com/docs/3.3/assets/js/ie-emulation-modes-warning.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>


    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/gallery-grid.css')); ?>">
    <!-- Bootstrap core CSS -->


    <!-- galeray -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">

    <!--table CSS -->
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/gallery-grid.css')); ?>">

    <!-- Bootstrap core CSS -->

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" type="text/css"
          rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
    <!-- Custom styles for this template -->
    <link href="http://bootstrap-3.ru/examples/offcanvas/offcanvas.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">

    <!--<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet"> -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!--Yandex -->
    <meta name="yandex-verification" content="af4168af7d682a89"/>

</head>

<body>


<script src="<?php echo e(asset('/js/axios.min.js')); ?>"></script>


<div class="container">
    <div class="card-body" id="app2">
        <carouseltemp></carouseltemp>
    </div>
    <div class="row row-offcanvas row-offcanvas-right">

        <div class="col-xs-12 col-sm-9">
            <p class="pull-right visible-xs">
                <button type="button" class="menuButton" data-toggle="offcanvas"><b>Меню</b></button>
            </p>


            <div class="row">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>

        <div class="col-xs-6 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">
            <div class="card-body" id="app">
                <?php if(Auth::guest()): ?>
                    <b><a href="<?php echo e(url('/login')); ?>">Войти</a></b><br>
                    <b><a href="<?php echo e(url('/join')); ?>">Зарегистрироваться</a></b>
                <?php else: ?>
                    <b><?php echo e(auth()->user()->name); ?></b><br>
                    <b><a href="<?php echo e(url('/logout')); ?>">Выйти</a></b>
                    <br>
                    <?php if($girl=Auth::user()->anketisExsis()!=null): ?>
                    <!-- <?php echo e($girl=Auth::user()->anketisExsis()); ?> -->
                        <img height="150" width="150"
                             src="<?php echo asset("images/small/$girl->main_image")?>">
                        <side-panel :user="<?php echo e(auth()->user()); ?>"></side-panel>
                    <?php else: ?>
                        <b><a class="btn btn-primary" href="<?php echo e(route('createGirlPage')); ?>">Создать анкету</a> </b>
                    <?php endif; ?>
                    <br><br>
                    <!--check is admin -->
                    <?php if(Auth::user()->is_admin==1): ?>
                        <b><a class="btn btn-success" href="<?php echo e(route('adminPanel')); ?>">Панель администратора</a> </b>
                    <?php endif; ?>
                    <b><a class="btn btn-success" href="<?php echo e(route('main')); ?>">На главную</a> </b>

                <?php endif; ?>
            </div>
        </div><!--/span-->
    </div><!--/row-->


</div>
<script src="http://bootstrap-3.ru/dist/js/bootstrap.min.js"></script>
<script src="http://bootstrap-3.ru/examples/offcanvas/offcanvas.js"></script>
<!-- скрипт для галлереи -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
<script>
    baguetteBox.run('.tz-gallery');

    function relocate_home() {
        location.href = "www.yoursite.com";
    }
</script>
</body>
</html>