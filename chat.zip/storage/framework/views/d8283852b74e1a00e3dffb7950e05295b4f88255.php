<?php $__env->startSection('content'); ?>
    <div class="card-body" id="app4">
        <mypresents :user="<?php echo e(auth()->user()); ?>"></mypresents>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', ['title' => 'Управление подарками'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>