<?php $__env->startSection('content'); ?>
    <?php if(Auth::guest()): ?>
    <?php else: ?>
        <?php if($girl->user_id!=auth()->user()->id): ?>
            <div class="card-body" id="app7">
                <privatepanel :id="<?php echo e($girl->id); ?>"></privatepanel>
            </div>
        <?php else: ?>
            Редактировать анкету
        <?php endif; ?>
        <?php if(auth()->user()->get_id()!=$girl->user_id): ?>

        <?php endif; ?>
    <?php endif; ?>
    <br>


    <br>
    <img height="250" width="250" src="<?php echo asset("/images/upload/$girl->main_image")?>">

    <h4 class="card-title">
        <?php echo e($girl->name); ?>

    </h4>

    <b>Пол:</b>
    <?php if($girl->sex=='famele'): ?>
        <b> Женский</b>
    <?php endif; ?>

    <?php if($girl->sex=='male'): ?>
        <b> Мужской</b>
    <?php endif; ?>
    <br>

    <p class="card-text"><b>Рост : <?php echo e($girl->height); ?></b>
    <p class="card-text"><b>Вес : <?php echo e($girl->weight); ?></b>
    <p class="card-text"><b>Возраст : <?php echo e($girl->age); ?></b>

    <p class="card-text"><b>Хочу встретиться с :</b> <?php if($girl->meet=='famele'): ?>
            <b> женщиной</b>
        <?php endif; ?>

        <?php if($girl->meet=='male'): ?>
            <b> мужчиной</b>
        <?php endif; ?>
        <b>Цели знакомства:</b> <br>

    <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $target): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><b><?php echo e($target->name); ?></b></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <p class="card-text"><b> <?php echo $girl->description; ?></b></p>

    <?php if($girl->private!=null): ?>
        <label>Приватное сообщение:</label>
        <p class="card-text>"><b><?php echo $girl->private; ?><</b></p>
    <?php endif; ?>
    <br>
    <div class="container gallery-container">
        <div class="tz-gallery">

            <div class="row">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-md-4">
                        <a class="lightbox" href="<?php echo asset("/images/upload/$image->photo_name")?>">
                            <img height="250" src="<?php echo asset("/images/upload/$image->photo_name")?>">
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <?php if($girl->private!=null): ?>
        <label>Приватное сообщение:</label>
        <p class="card-text>"><b><?php echo $girl->private; ?><</b></p>
        <?php if(empty($privatephotos)): ?>
        <?php else: ?>
            <label>Приватные фотографии:</label>
            <div class="container gallery-container">
                <div class="tz-gallery">
                    <div class="row">
                        <?php $__currentLoopData = $privatephotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6 col-md-4">
                                <a class="lightbox" href="<?php echo asset("/images/upload/$image->photo_name")?>">
                                    <img height="250" src="<?php echo asset("/images/upload/$image->photo_name")?>">
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <br>

    <a class="btn btn-primary" href="<?php echo e(route('main')); ?>" role="link" onclick=" relocate_home()">К списку анкет</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', ['title' => $girl->name], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>