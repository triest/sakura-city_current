<?php $__env->startSection('content'); ?>

    <b><a class="btn btn-success" href="<?php echo e(route('presentsControll')); ?>">Управление подарками</a> </b>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', ['title' => 'Панель администратора'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>