<?php $__env->startSection('content'); ?>
    <div class="card-body" id="app4">
        <presents :user="<?php echo e(auth()->user()); ?>"></presents>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', ['title' => 'Управление подарками'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>